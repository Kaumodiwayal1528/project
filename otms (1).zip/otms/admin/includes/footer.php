<footer class="footer">
          <div class="card">
            <div class="card-body">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted d-block text-center text-sm-left d-sm-inline-block"><center>Smart Temple System © 2022  <?php echo date('Y');?></center></span>
              </div>
            </div>
          </div>
        </footer>